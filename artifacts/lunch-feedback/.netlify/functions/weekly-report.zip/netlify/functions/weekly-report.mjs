
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// lib/db/src/index.ts
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";

// lib/db/src/schema/index.ts
var schema_exports = {};
__export(schema_exports, {
  emailLogsTable: () => emailLogsTable,
  emailSettingsTable: () => emailSettingsTable,
  feedbackTable: () => feedbackTable,
  insertFeedbackSchema: () => insertFeedbackSchema,
  insertMenuSchema: () => insertMenuSchema,
  menusTable: () => menusTable,
  syncLogsTable: () => syncLogsTable,
  weeklyReportsTable: () => weeklyReportsTable
});

// lib/db/src/schema/feedback.ts
import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var feedbackTable = pgTable("feedback", {
  id: serial("id").primaryKey(),
  meal: text("meal").notNull(),
  mealName: text("meal_name"),
  rating: text("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});
var insertFeedbackSchema = createInsertSchema(feedbackTable).omit({ id: true, createdAt: true });

// lib/db/src/schema/menus.ts
import { pgTable as pgTable2, text as text2, serial as serial2, timestamp as timestamp2, date, unique, integer } from "drizzle-orm/pg-core";
import { createInsertSchema as createInsertSchema2 } from "drizzle-zod";
var menusTable = pgTable2(
  "menus",
  {
    id: serial2("id").primaryKey(),
    date: date("date").notNull(),
    mealType: text2("meal_type").notNull(),
    name: text2("name").notNull(),
    syncedAt: timestamp2("synced_at", { withTimezone: true }).notNull().defaultNow()
  },
  (t) => [unique("menus_date_meal_type_unique").on(t.date, t.mealType)]
);
var insertMenuSchema = createInsertSchema2(menusTable).omit({ id: true, syncedAt: true });
var syncLogsTable = pgTable2("sync_logs", {
  id: serial2("id").primaryKey(),
  triggeredAt: timestamp2("triggered_at", { withTimezone: true }).defaultNow().notNull(),
  source: text2("source").notNull().default("strava"),
  synced: integer("synced").notNull().default(0),
  error: text2("error")
});

// lib/db/src/schema/weekly-reports.ts
import { pgTable as pgTable3, text as text3, serial as serial3, timestamp as timestamp3, date as date2, integer as integer2, jsonb } from "drizzle-orm/pg-core";
var weeklyReportsTable = pgTable3("weekly_reports", {
  id: serial3("id").primaryKey(),
  weekStart: date2("week_start").notNull().unique(),
  totalFeedback: integer2("total_feedback").notNull().default(0),
  positiveCount: integer2("positive_count").notNull().default(0),
  neutralCount: integer2("neutral_count").notNull().default(0),
  negativeCount: integer2("negative_count").notNull().default(0),
  bestMeal: text3("best_meal"),
  worstMeal: text3("worst_meal"),
  topComments: jsonb("top_comments").$type().notNull().default([]),
  mealBreakdown: jsonb("meal_breakdown").$type().notNull().default([]),
  generatedAt: timestamp3("generated_at", { withTimezone: true }).notNull().defaultNow()
});

// lib/db/src/schema/email.ts
import { pgTable as pgTable4, text as text4, serial as serial4, timestamp as timestamp4, boolean } from "drizzle-orm/pg-core";
var emailSettingsTable = pgTable4("email_settings", {
  id: serial4("id").primaryKey(),
  recipients: text4("recipients").notNull().default(""),
  fromAddress: text4("from_address").notNull().default("noreply@gymnas.cz"),
  enabled: boolean("enabled").notNull().default(false),
  updatedAt: timestamp4("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var emailLogsTable = pgTable4("email_logs", {
  id: serial4("id").primaryKey(),
  sentAt: timestamp4("sent_at", { withTimezone: true }).defaultNow().notNull(),
  recipients: text4("recipients").notNull(),
  status: text4("status").notNull(),
  error: text4("error"),
  weekStart: text4("week_start")
});

// lib/db/src/index.ts
var { Pool } = pg;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db = drizzle(pool, { schema: schema_exports });
export {
  db,
  emailLogsTable,
  emailSettingsTable,
  feedbackTable,
  insertFeedbackSchema,
  insertMenuSchema,
  menusTable,
  pool,
  syncLogsTable,
  weeklyReportsTable
};
